<?php
/*
Plugin Name: 远程图片本地化增强插件V1.0
Plugin URI: apthub.top
Description: 该插件可在WordPress保存文章时自动将远程图片本地化到本地指定目录，保留图片原有格式，并确保图片页面链接为绝对地址。
Version: 1.0
Author: apthub
Author URI: apthub.top
License: GPL2
*/

// 定义函数用于获取唯一文件名（处理重名情况）
function get_unique_filename($filename) {
    $pathinfo = pathinfo($filename);
    $name = $pathinfo['filename'];
    $ext = isset($pathinfo['extension'])? '.'. $pathinfo['extension'] : '';
    $counter = 1;
    while (file_exists($filename)) {
        $filename = $pathinfo['dirname']. '/'. $name. '_'. $counter++. $ext;
    }
    return $filename;
}

// 定义本地化图片函数（改进版）
function localize_image($image_url, $local_dir) {
    // 获取远程图片的扩展名
    $ext = pathinfo($image_url, PATHINFO_EXTENSION);
    // 生成一个唯一的文件名（基于原文件名及避免重名规则）
    $image_name = uniqid(). '.'. $ext;
    $local_path = $local_dir. '/'. $image_name;
    $local_path = get_unique_filename($local_path);

    // 获取远程图片内容
    $image_content = file_get_contents($image_url);
    if ($image_content === false) {
        return false;
    }

    // 将图片内容写入本地文件
    $fp = fopen($local_path, 'w');
    if ($fp === false) {
        return false;
    }
    fwrite($fp, $image_content);
    fclose($fp);

    return $local_path;
}

// 挂钩到文章保存动作（改进版）
function localize_remote_images_in_post($post_id) {
    // 检查是否是自动保存等情况，如果是则不执行
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    // 获取文章内容
    $post = get_post($post_id);
    $content = $post->post_content;

    // 匹配文章内容中的图片链接（这里简单匹配img标签中的src属性，实际可能更复杂）
    preg_match_all('/<img.*?src="(.*?)".*?>/i', $content, $matches);
    $image_urls = $matches[1];

    // 定义本地保存图片的目录（这里假设是wp-content/uploads/remote_images ，可按需调整）
    $uploads_dir = wp_upload_dir();
    $local_image_dir = $uploads_dir['basedir']. '/remote_images';
    if (!is_dir($local_image_dir)) {
        mkdir($local_image_dir);
    }

    foreach ($image_urls as $image_url) {
        // 检查是否是远程图片链接（这里简单判断是否以http或https开头，可完善）
        if (strpos($image_url, 'http') === 0) {
            $local_path = localize_image($image_url, $local_image_dir);
            if ($local_path) {
                // 获取完整的本地图片绝对地址（用于替换文章中的链接）
                $local_absolute_url = $uploads_dir['baseurl']. '/remote_images/'. basename($local_path);
                // 替换文章内容中的远程图片链接为本地绝对地址
                $content = str_replace($image_url, $local_absolute_url, $content);
            }
        }
    }

    // 更新文章内容为替换后的内容
    wp_update_post(array(
        'ID' => $post_id,
        'post_content' => $content
    ));
}
add_action('save_post', 'localize_remote_images_in_post');